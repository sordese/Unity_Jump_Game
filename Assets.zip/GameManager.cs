using UnityEngine;

public class GameManager : MonoBehaviour
{
    public GameObject obstaclePrefab;
    public float spawnTime = 2f;

    void Start()
    {
        InvokeRepeating("SpawnObstacle", 1f, spawnTime);
    }

    void SpawnObstacle()
    {
        Instantiate(obstaclePrefab, new Vector2(8, 0), Quaternion.identity);
    }
}