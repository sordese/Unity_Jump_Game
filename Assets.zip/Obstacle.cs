using UnityEngine;

public class Obstacle : MonoBehaviour
{
    public float speed = 5f;
    bool hasScored = false;
    Transform player;

    void Start()
    {
        player = GameObject.Find("Player").transform;
    }

    void Update()
    {
        speed += Time.deltaTime * 0.5f;

        transform.Translate(Vector2.left * speed * Time.deltaTime);

        if (!hasScored && transform.position.x < player.position.x)
        {
            hasScored = true;
            FindObjectOfType<PlayerController>().AddScore();
        }
    }
}