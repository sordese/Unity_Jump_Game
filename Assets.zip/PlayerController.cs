using UnityEngine;
using TMPro;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rb;
    public float jumpForce = 6f;

    bool isGrounded = true;
    float score = 0;

    public TextMeshProUGUI scoreText;

    Vector2 startPosition;  // ���� ��ġ ����

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        startPosition = transform.position;  // ���� ��ġ ���
    }

    void Update()
    {
        // ���� UI ������Ʈ
        scoreText.text = "Score: " + score;

        // ����
        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpForce);
            isGrounded = false;
        }

        // �� ������ ��ġ�� �ʱ�ȭ
        if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            transform.position = startPosition;   // ��ġ �̵�
            rb.linearVelocity = Vector2.zero;     // �ӵ� �ʱ�ȭ
            isGrounded = true;                    // �ٷ� ���� ����
        }
    }

    public void AddScore()
    {
        score += 1;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "Ground")
        {
            isGrounded = true;
        }

        if (collision.gameObject.name.Contains("Obstacle"))
        {
            Time.timeScale = 0f;
            Debug.Log("Game Over");
        }
    }
}